#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <string.h>
#include <time.h>

#define MAX_FILES 10
#define MAX_USERS 100

typedef struct {
    int read_time;
    int write_time;
    int delete_time;
    int max_files;
    int max_concurrent_users;
    int max_wait_time;
} FileManager;

typedef struct {
    int user_id;
    int file_id;
    char operation[10];
    int request_time;
} UserRequest;

FileManager fm; // Global FileManager instance
pthread_mutex_t file_locks[MAX_FILES];
pthread_mutex_t write_locks[MAX_FILES];
int readers_count[MAX_FILES] = {0};
int file_status[MAX_FILES] = {1}; // 1 for active, 0 for deleted
int active_requests = 0;
pthread_mutex_t request_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t cond = PTHREAD_COND_INITIALIZER;
int is_awake = 0;

void* process_request(void* arg);
void handle_read(int file_id, int user_id);
void handle_write(int file_id, int user_id);
void handle_delete(int file_id, int user_id);
void add_request(UserRequest request);

int main() {
    printf("Enter read, write, delete times: ");
    scanf("%d %d %d", &fm.read_time, &fm.write_time, &fm.delete_time);
    printf("Enter number of files, max concurrent users, max wait time: ");
    scanf("%d %d %d", &fm.max_files, &fm.max_concurrent_users, &fm.max_wait_time);

    // Initialize mutexes and file status
    for (int i = 0; i < fm.max_files; i++) {
        pthread_mutex_init(&file_locks[i], NULL);
        pthread_mutex_init(&write_locks[i], NULL);
        readers_count[i] = 0;
        file_status[i] = 1;
    }

    printf("LAZY has woken up!\n");
    is_awake = 1;

    while (1) {
        UserRequest request;
        printf("Enter user ID, file ID, operation (READ/WRITE/DELETE), request time (or STOP to end): ");
        char operation[10];
        if (scanf("%d %d %s %d", &request.user_id, &request.file_id, operation, &request.request_time) != 4) {
            break;
        }
        
        // Validate input
        if (request.file_id >= fm.max_files || request.file_id < 0) {
            printf("Invalid file ID\n");
            continue;
        }
        
        strcpy(request.operation, operation);
        add_request(request);
    }

    // Cleanup
    for (int i = 0; i < fm.max_files; i++) {
        pthread_mutex_destroy(&file_locks[i]);
        pthread_mutex_destroy(&write_locks[i]);
    }
    pthread_mutex_destroy(&request_mutex);

    printf("LAZY has no more pending requests and is going back to sleep!\n");
    return 0;
}

void add_request(UserRequest request) {
    printf("User %d has made request for performing %s on file %d at %d seconds [YELLOW]\n",
           request.user_id, request.operation, request.file_id, request.request_time);

    UserRequest* req = malloc(sizeof(UserRequest));
    *req = request;

    pthread_t thread;
    pthread_create(&thread, NULL, process_request, (void*)req);
    pthread_detach(thread);
}

void* process_request(void* arg) {
    UserRequest* req = (UserRequest*)arg;
    UserRequest request = *req;
    free(req);

    // Wait for request time
    sleep(request.request_time);

    if (!is_awake) {
        printf("LAZY is asleep, request cancelled for User %d\n", request.user_id);
        return NULL;
    }

    pthread_mutex_lock(&request_mutex);
    if (active_requests >= fm.max_concurrent_users) {
        printf("Too many concurrent requests, request cancelled for User %d\n", request.user_id);
        pthread_mutex_unlock(&request_mutex);
        return NULL;
    }
    active_requests++;
    pthread_mutex_unlock(&request_mutex);

    printf("LAZY has taken up the request of User %d at %d seconds [PINK]\n", 
           request.user_id, (int)time(NULL));

    if (strcmp(request.operation, "READ") == 0) {
        handle_read(request.file_id, request.user_id);
    } else if (strcmp(request.operation, "WRITE") == 0) {
        handle_write(request.file_id, request.user_id);
    } else if (strcmp(request.operation, "DELETE") == 0) {
        handle_delete(request.file_id, request.user_id);
    }

    pthread_mutex_lock(&request_mutex);
    active_requests--;
    pthread_mutex_unlock(&request_mutex);

    return NULL;
}

void handle_read(int file_id, int user_id) {
    pthread_mutex_lock(&file_locks[file_id]);
    
    if (!file_status[file_id]) {
        printf("LAZY has declined the request of User %d at %d seconds because file %d is deleted [WHITE]\n", 
               user_id, (int)time(NULL), file_id);
        pthread_mutex_unlock(&file_locks[file_id]);
        return;
    }

    readers_count[file_id]++;
    pthread_mutex_unlock(&file_locks[file_id]);

    sleep(fm.read_time);
    
    pthread_mutex_lock(&file_locks[file_id]);
    readers_count[file_id]--;
    printf("The request for User %d was completed at %d seconds [GREEN]\n", 
           user_id, (int)time(NULL));
    pthread_mutex_unlock(&file_locks[file_id]);
}

void handle_write(int file_id, int user_id) {
    pthread_mutex_lock(&write_locks[file_id]);
    pthread_mutex_lock(&file_locks[file_id]);

    if (!file_status[file_id]) {
        printf("LAZY has declined the request of User %d at %d seconds because file %d is deleted [WHITE]\n", 
               user_id, (int)time(NULL), file_id);
        pthread_mutex_unlock(&file_locks[file_id]);
        pthread_mutex_unlock(&write_locks[file_id]);
        return;
    }

    if (readers_count[file_id] > 0) {
        printf("LAZY has declined the request of User %d at %d seconds because file %d is being read [WHITE]\n", 
               user_id, (int)time(NULL), file_id);
        pthread_mutex_unlock(&file_locks[file_id]);
        pthread_mutex_unlock(&write_locks[file_id]);
        return;
    }

    sleep(fm.write_time);
    
    printf("The request for User %d was completed at %d seconds [GREEN]\n", 
           user_id, (int)time(NULL));
    
    pthread_mutex_unlock(&file_locks[file_id]);
    pthread_mutex_unlock(&write_locks[file_id]);
}

void handle_delete(int file_id, int user_id) {
    pthread_mutex_lock(&write_locks[file_id]);
    pthread_mutex_lock(&file_locks[file_id]);

    if (!file_status[file_id]) {
        printf("LAZY has declined the request of User %d at %d seconds because file %d is already deleted [WHITE]\n", 
                user_id, (int)time(NULL), file_id);
        pthread_mutex_unlock(&file_locks[file_id]);
        pthread_mutex_unlock(&write_locks[file_id]);
        return;
    }

    if (readers_count[file_id] > 0) {
        printf("LAZY has declined the request of User %d at %d seconds because file %d is being read [WHITE]\n", 
               user_id, (int)time(NULL), file_id);
        pthread_mutex_unlock(&file_locks[file_id]);
        pthread_mutex_unlock(&write_locks[file_id]);
        return;
    }

    sleep(fm.delete_time);
    
    file_status[file_id] = 0;
    printf("The request for User %d was completed at %d seconds [GREEN]\n", 
           user_id, (int)time(NULL));
    
    pthread_mutex_unlock(&file_locks[file_id]);
    pthread_mutex_unlock(&write_locks[file_id]);
}